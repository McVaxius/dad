from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import shutil
import sys
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable


JsonObject = dict[str, Any]


class DadConfigError(RuntimeError):
    pass


def fail(message: str) -> None:
    raise DadConfigError(message)


def guid_n() -> str:
    return uuid.uuid4().hex


def utc_now_text() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f0Z")


def require_object(value: Any, label: str) -> JsonObject:
    if not isinstance(value, dict):
        fail(f"{label} is not a JSON object.")
    return value


def require_object_list(value: Any, label: str) -> list[JsonObject]:
    if not isinstance(value, list) or not all(isinstance(item, dict) for item in value):
        fail(f"{label} is not a list of JSON objects.")
    return value


class Document:
    def __init__(self, path: Path) -> None:
        self.path = path.resolve()
        self.raw = self.path.read_bytes()
        self.digest = hashlib.sha256(self.raw).hexdigest()

        if self.raw.startswith(b"\xef\xbb\xbf"):
            self.bom, self.codec = b"\xef\xbb\xbf", "utf-8"
        elif self.raw.startswith(b"\xff\xfe"):
            self.bom, self.codec = b"\xff\xfe", "utf-16-le"
        elif self.raw.startswith(b"\xfe\xff"):
            self.bom, self.codec = b"\xfe\xff", "utf-16-be"
        else:
            self.bom, self.codec = b"", "utf-8"

        text = self.raw[len(self.bom) :].decode(self.codec)
        self.newline = "\r\n" if "\r\n" in text else "\n"
        self.data = require_object(json.loads(text), "Configuration root")

    def encode(self, data: JsonObject) -> bytes:
        text = json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
        if self.newline != "\n":
            text = text.replace("\n", self.newline)
        return self.bom + text.encode(self.codec)

    def write(self, data: JsonObject, label: str) -> Path | None:
        if data == self.data:
            return None

        current = self.path.read_bytes()
        if hashlib.sha256(current).hexdigest() != self.digest:
            fail("The configuration changed after it was read; no changes were written.")

        output = self.encode(data)
        parsed_output = require_object(
            json.loads(output[len(self.bom) :].decode(self.codec)), "Encoded output"
        )
        if parsed_output != data:
            fail("Encoded JSON does not round-trip before writing.")

        safe_label = re.sub(r"[^a-z0-9-]+", "-", label.lower()).strip("-") or "update"
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = self.path.with_name(self.path.name + f".codex-backup-{safe_label}-{stamp}")
        temp = self.path.with_name(self.path.name + f".codex-tmp-{os.getpid()}")
        if backup.exists() or temp.exists():
            fail("Backup or temporary path already exists; no changes were written.")

        try:
            with temp.open("xb") as handle:
                handle.write(output)
                handle.flush()
                os.fsync(handle.fileno())
            temp_data = require_object(
                json.loads(temp.read_bytes()[len(self.bom) :].decode(self.codec)),
                "Temporary output",
            )
            if temp_data != data:
                fail("Temporary JSON differs from the validated output.")
            shutil.copy2(self.path, backup)
            os.replace(temp, self.path)
        finally:
            if temp.exists():
                temp.unlink()

        final = Document(self.path)
        if final.data != data:
            fail("Final on-disk JSON differs from the validated output.")
        return backup


def planner_groups(data: JsonObject) -> list[JsonObject]:
    return require_object_list(data.get("PlannerGroups"), "PlannerGroups")


def schedules(data: JsonObject) -> list[JsonObject]:
    return require_object_list(data.get("Schedules"), "Schedules")


def group_index(groups: list[JsonObject]) -> dict[str, JsonObject]:
    result: dict[str, JsonObject] = {}
    for group in groups:
        group_id = group.get("GroupId")
        if not isinstance(group_id, str) or not group_id:
            fail("A PlannerGroup has an empty or non-string GroupId.")
        if group_id in result:
            fail(f"Duplicate PlannerGroup ID: {group_id}")
        result[group_id] = group
    return result


def named_one(items: list[JsonObject], name: str, label: str) -> JsonObject:
    matches = [item for item in items if item.get("DisplayName") == name]
    if len(matches) != 1:
        fail(f"Expected exactly one {label} named {name!r}, found {len(matches)}.")
    return matches[0]


def iter_slots(data: JsonObject):
    for group in planner_groups(data):
        slots = require_object_list(group.get("Slots", []), f"Slots for {group.get('DisplayName')!r}")
        for slot in slots:
            yield group, slot


def inspect_config(data: JsonObject) -> JsonObject:
    groups = planner_groups(data)
    schedule_list = schedules(data)
    by_id = group_index(groups)
    slots = [slot for _, slot in iter_slots(data)]

    roulette_counts: Counter[str] = Counter()
    for group in groups:
        target = group.get("RouletteTarget")
        if isinstance(target, dict):
            key = f"{target.get('RouletteId')} | {target.get('DisplayName')}"
        else:
            key = "<missing>"
        roulette_counts[key] += 1

    level_counts: Counter[str] = Counter(
        "null" if slot.get("LevelSeekTarget") is None else str(slot.get("LevelSeekTarget"))
        for slot in slots
    )
    daily_true = sum(slot.get("SkipIfDailyRouletteRewardReceived") is True for slot in slots)
    missing_refs = [
        {
            "schedule": schedule.get("DisplayName"),
            "group_id": entry.get("GroupId"),
            "preset_name": entry.get("PresetName"),
        }
        for schedule in schedule_list
        for entry in require_object_list(
            schedule.get("Entries", []), f"Entries for {schedule.get('DisplayName')!r}"
        )
        if entry.get("GroupId") not in by_id
    ]
    return {
        "planner_groups": len(groups),
        "character_slots": len(slots),
        "daily_true": daily_true,
        "daily_not_true": len(slots) - daily_true,
        "level_seek_targets": dict(sorted(level_counts.items())),
        "roulette_targets": dict(sorted(roulette_counts.items())),
        "schedules": [
            {
                "name": schedule.get("DisplayName"),
                "entries": len(require_object_list(schedule.get("Entries", []), "Schedule entries")),
                "cadence": schedule.get("Cadence"),
            }
            for schedule in schedule_list
        ],
        "missing_schedule_group_references": missing_refs,
    }


def set_level_seek(data: JsonObject, from_value: int, to_value: int) -> JsonObject:
    changed_groups: set[str] = set()
    changes = 0
    for group, slot in iter_slots(data):
        value = slot.get("LevelSeekTarget")
        if not isinstance(value, bool) and value == from_value:
            slot["LevelSeekTarget"] = to_value
            changes += 1
            changed_groups.add(str(group.get("DisplayName")))
    return {
        "operation": "set-level-seek",
        "from_value": from_value,
        "to_value": to_value,
        "changes": changes,
        "affected_presets": len(changed_groups),
        "remaining_from_value": sum(
            slot.get("LevelSeekTarget") == from_value for _, slot in iter_slots(data)
        ),
    }


def enable_daily(data: JsonObject) -> JsonObject:
    changes = 0
    changed_groups: set[str] = set()
    for group, slot in iter_slots(data):
        if slot.get("SkipIfDailyRouletteRewardReceived") is not True:
            slot["SkipIfDailyRouletteRewardReceived"] = True
            changes += 1
            changed_groups.add(str(group.get("DisplayName")))
    slots = [slot for _, slot in iter_slots(data)]
    return {
        "operation": "enable-daily",
        "changes": changes,
        "affected_presets": len(changed_groups),
        "total_slots": len(slots),
        "daily_true": sum(slot.get("SkipIfDailyRouletteRewardReceived") is True for slot in slots),
        "daily_not_true": sum(
            slot.get("SkipIfDailyRouletteRewardReceived") is not True for slot in slots
        ),
    }


def replace_prefix(name: str, source_prefix: str, target_prefix: str) -> str:
    if name == source_prefix:
        return target_prefix
    prefix = source_prefix + " "
    if name.startswith(prefix):
        return target_prefix + " " + name[len(prefix) :]
    fail(f"Preset {name!r} does not start with source prefix {source_prefix!r}.")


def new_schedule_entry(
    prototype: JsonObject, group_id: str, preset_name: str, now: str
) -> JsonObject:
    entry = copy.deepcopy(prototype)
    entry["EntryId"] = guid_n()
    entry["GroupId"] = group_id
    entry["PresetName"] = preset_name
    entry["RepeatCount"] = 1
    entry["CreatedAtUtc"] = now
    entry["UpdatedAtUtc"] = now
    return entry


def new_schedule(
    source: JsonObject, display_name: str, entries: list[JsonObject], now: str
) -> JsonObject:
    result = copy.deepcopy(source)
    result["Revision"] = 1
    result["ScheduleId"] = guid_n()
    result["DisplayName"] = display_name
    result["Entries"] = entries
    result["CreatedAtUtc"] = now
    result["UpdatedAtUtc"] = now
    result["LastDailyResetUtc"] = None
    result["LastRunStartedAtUtc"] = None
    result["LastRunCompletedAtUtc"] = None
    result["LastRunStatus"] = 0
    result["LastSummary"] = ""
    return result


def comparable_group(group: JsonObject) -> JsonObject:
    result = copy.deepcopy(group)
    for key in ("GroupId", "DisplayName", "RouletteTarget", "CreatedAtUtc", "UpdatedAtUtc"):
        result.pop(key, None)
    return result


def clone_roulette_schedule(data: JsonObject, args: argparse.Namespace) -> JsonObject:
    groups = planner_groups(data)
    schedule_list = schedules(data)
    by_id = group_index(groups)
    source_schedule = named_one(schedule_list, args.source_schedule, "schedule")
    template = named_one(groups, args.roulette_template, "roulette template preset")
    target = require_object(template.get("RouletteTarget"), "Roulette template target")

    existing_schedule_names = [item.get("DisplayName") for item in schedule_list]
    for name in (args.target_schedule, args.combined_schedule):
        if name in existing_schedule_names:
            fail(f"Schedule {name!r} already exists.")
    if args.target_schedule == args.combined_schedule:
        fail("Target and combined schedule names must differ.")

    source_entries = require_object_list(source_schedule.get("Entries"), "Source schedule entries")
    if args.expected_source_count is not None and len(source_entries) != args.expected_source_count:
        fail(
            f"Expected {args.expected_source_count} source entries, found {len(source_entries)}."
        )
    if not source_entries:
        fail("The source schedule has no entries.")
    source_ids = [entry.get("GroupId") for entry in source_entries]
    if not all(isinstance(group_id, str) and group_id for group_id in source_ids):
        fail("A source schedule entry has an invalid GroupId.")
    if len(set(source_ids)) != len(source_ids):
        fail("The source schedule must reference distinct PlannerGroups.")
    missing = [group_id for group_id in source_ids if group_id not in by_id]
    if missing:
        fail(f"Source schedule references missing PlannerGroups: {missing}")
    source_groups = [by_id[group_id] for group_id in source_ids]

    source_names = [group.get("DisplayName") for group in source_groups]
    if not all(isinstance(name, str) and name for name in source_names):
        fail("A source PlannerGroup has an invalid DisplayName.")
    if len(set(source_names)) != len(source_names):
        fail("Source PlannerGroup display names are not unique.")
    target_names = [replace_prefix(name, args.source_prefix, args.target_prefix) for name in source_names]
    if len(set(target_names)) != len(target_names):
        fail("Derived target PlannerGroup names are not unique.")

    retire_names = args.retire_preset or []
    if len(set(retire_names)) != len(retire_names):
        fail("A --retire-preset name was supplied more than once.")
    retired = [named_one(groups, name, "retired preset") for name in retire_names]
    retired_ids = [group["GroupId"] for group in retired]
    if len(retired_ids) > len(source_groups):
        fail("Cannot retire more preset IDs than the number of target copies.")
    if set(retired_ids).intersection(source_ids):
        fail("A source-schedule preset cannot be retired.")

    existing_schedule_refs: dict[str, list[str]] = {}
    for schedule in schedule_list:
        for entry in require_object_list(schedule.get("Entries", []), "Existing schedule entries"):
            group_id = entry.get("GroupId")
            existing_schedule_refs.setdefault(str(group_id), []).append(str(schedule.get("DisplayName")))
    referenced_retired = {
        group["DisplayName"]: existing_schedule_refs[group["GroupId"]]
        for group in retired
        if group["GroupId"] in existing_schedule_refs
    }
    if referenced_retired:
        fail(f"Cannot retire presets referenced by existing schedules: {referenced_retired}")

    retained = [group for group in groups if group["GroupId"] not in set(retired_ids)]
    retained_names = {str(group.get("DisplayName")) for group in retained}
    collisions = sorted(retained_names.intersection(target_names))
    if collisions:
        fail(f"Derived target names collide with retained PlannerGroups: {collisions}")

    new_ids = retired_ids + [guid_n() for _ in range(len(source_groups) - len(retired_ids))]
    if len(set(new_ids)) != len(source_groups) or set(new_ids).intersection(source_ids):
        fail("Generated target PlannerGroup IDs are not unique.")

    now = utc_now_text()
    new_groups: list[JsonObject] = []
    for source, new_id, target_name in zip(source_groups, new_ids, target_names, strict=True):
        duplicate = copy.deepcopy(source)
        duplicate["GroupId"] = new_id
        duplicate["DisplayName"] = target_name
        duplicate["RouletteTarget"] = copy.deepcopy(target)
        duplicate["CreatedAtUtc"] = now
        duplicate["UpdatedAtUtc"] = now
        if comparable_group(source) != comparable_group(duplicate):
            fail(f"Clone validation failed for {target_name!r}.")
        new_groups.append(duplicate)
    data["PlannerGroups"] = retained + new_groups

    prototype = source_entries[0]
    target_entries = [
        new_schedule_entry(prototype, group["GroupId"], group["DisplayName"], now)
        for group in new_groups
    ]
    combined_entries: list[JsonObject] = []
    for source, duplicate in zip(source_groups, new_groups, strict=True):
        combined_entries.append(
            new_schedule_entry(prototype, source["GroupId"], source["DisplayName"], now)
        )
        combined_entries.append(
            new_schedule_entry(prototype, duplicate["GroupId"], duplicate["DisplayName"], now)
        )

    target_schedule = new_schedule(source_schedule, args.target_schedule, target_entries, now)
    combined_schedule = new_schedule(
        source_schedule, args.combined_schedule, combined_entries, now
    )
    data["Schedules"] = schedule_list + [target_schedule, combined_schedule]

    final_groups = planner_groups(data)
    final_by_id = group_index(final_groups)
    if args.expected_final_count is not None and len(final_groups) != args.expected_final_count:
        fail(
            f"Expected {args.expected_final_count} final PlannerGroups, found {len(final_groups)}."
        )
    for duplicate in new_groups:
        if duplicate.get("RouletteTarget") != target:
            fail(f"RouletteTarget validation failed for {duplicate.get('DisplayName')!r}.")

    all_schedule_ids = [schedule.get("ScheduleId") for schedule in schedules(data)]
    if len(all_schedule_ids) != len(set(all_schedule_ids)):
        fail("Schedule IDs are not unique.")
    all_entry_ids = [
        entry.get("EntryId")
        for schedule in schedules(data)
        for entry in require_object_list(schedule.get("Entries", []), "Schedule entries")
    ]
    if len(all_entry_ids) != len(set(all_entry_ids)):
        fail("Schedule entry IDs are not unique.")
    missing_refs = [
        entry.get("GroupId")
        for schedule in schedules(data)
        for entry in require_object_list(schedule.get("Entries", []), "Schedule entries")
        if entry.get("GroupId") not in final_by_id
    ]
    if missing_refs:
        fail(f"Schedules contain missing PlannerGroup references: {missing_refs[:5]}")

    expected_combined = [value for pair in zip(source_ids, new_ids, strict=True) for value in pair]
    if [entry["GroupId"] for entry in target_entries] != new_ids:
        fail("Target-only schedule order is invalid.")
    if [entry["GroupId"] for entry in combined_entries] != expected_combined:
        fail("Combined schedule is not strictly source/target interleaved.")

    selected_id = require_object(data.get("PlannerOptions", {}), "PlannerOptions").get(
        "SelectedPlannerGroupId"
    )
    return {
        "operation": "clone-roulette-schedule",
        "planner_groups_before": len(groups),
        "planner_groups_after": len(final_groups),
        "source_presets": len(source_groups),
        "target_presets_created": len(new_groups),
        "retired_presets": retire_names,
        "roulette_target": {
            "roulette_id": target.get("RouletteId"),
            "key": target.get("Key"),
            "display_name": target.get("DisplayName"),
        },
        "target_schedule": {"name": args.target_schedule, "entries": len(target_entries)},
        "combined_schedule": {
            "name": args.combined_schedule,
            "entries": len(combined_entries),
        },
        "first_pairs": [
            [source_groups[index]["DisplayName"], new_groups[index]["DisplayName"]]
            for index in range(min(3, len(source_groups)))
        ],
        "last_pairs": [
            [source_groups[index]["DisplayName"], new_groups[index]["DisplayName"]]
            for index in range(max(0, len(source_groups) - 3), len(source_groups))
        ],
        "selected_group_id": selected_id,
        "selected_group_valid": selected_id in final_by_id if selected_id else True,
        "missing_schedule_group_references": 0,
    }


def add_write_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--expected-changes",
        type=int,
        help="Abort unless exactly this many slot values would change.",
    )
    parser.add_argument(
        "--write",
        action="store_true",
        help="Write atomically and create a backup. Without this flag, perform a dry-run.",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Safely inspect and update XIVLauncher DAD dad.json files."
    )
    parser.add_argument("config", type=Path, help="Path to dad.json")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("inspect", help="Read-only configuration summary")

    level = subparsers.add_parser("set-level-seek", help="Replace exact slot level targets")
    level.add_argument("--from-value", type=int, required=True)
    level.add_argument("--to-value", type=int, required=True)
    add_write_options(level)

    daily = subparsers.add_parser("enable-daily", help="Enable Daily on every planner slot")
    add_write_options(daily)

    clone = subparsers.add_parser(
        "clone-roulette-schedule",
        help="Clone scheduled presets for another roulette and add paired schedules",
    )
    clone.add_argument("--source-schedule", required=True)
    clone.add_argument("--roulette-template", required=True)
    clone.add_argument("--source-prefix", required=True)
    clone.add_argument("--target-prefix", required=True)
    clone.add_argument("--target-schedule", required=True)
    clone.add_argument("--combined-schedule", required=True)
    clone.add_argument("--expected-source-count", type=int)
    clone.add_argument("--expected-final-count", type=int)
    clone.add_argument(
        "--retire-preset",
        action="append",
        help="Exact unreferenced preset name to replace; repeat as needed.",
    )
    clone.add_argument(
        "--write",
        action="store_true",
        help="Write atomically and create a backup. Without this flag, perform a dry-run.",
    )
    return parser


def execute(args: argparse.Namespace) -> int:
    document = Document(args.config)
    if args.command == "inspect":
        print(json.dumps(inspect_config(document.data), ensure_ascii=False, indent=2))
        return 0

    updated = copy.deepcopy(document.data)
    label: str
    operation: Callable[[], JsonObject]
    if args.command == "set-level-seek":
        if args.from_value == args.to_value:
            fail("--from-value and --to-value must differ.")
        label = "level-seek"
        operation = lambda: set_level_seek(updated, args.from_value, args.to_value)
    elif args.command == "enable-daily":
        label = "daily"
        operation = lambda: enable_daily(updated)
    elif args.command == "clone-roulette-schedule":
        label = "roulette-schedules"
        operation = lambda: clone_roulette_schedule(updated, args)
    else:
        fail(f"Unsupported command: {args.command}")

    summary = operation()
    if hasattr(args, "expected_changes") and args.expected_changes is not None:
        if summary.get("changes") != args.expected_changes:
            fail(
                f"Expected {args.expected_changes} changes, found {summary.get('changes')}; "
                "no changes were written."
            )
    require_object(json.loads(document.encode(updated)[len(document.bom) :].decode(document.codec)), "Output")

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if not args.write:
        print("DRY RUN: no changes written")
        return 0

    backup = document.write(updated, label)
    if backup is None:
        print("WRITE SKIPPED: configuration already matched the request")
    else:
        print(f"Backup: {backup}")
        print("WRITE COMPLETE: validation passed")
    return 0


def main() -> int:
    return execute(build_parser().parse_args())


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (DadConfigError, FileNotFoundError, PermissionError, UnicodeError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
