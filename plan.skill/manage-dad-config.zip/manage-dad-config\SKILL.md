---
name: manage-dad-config
description: Safely inspect and update XIVLauncher DAD plugin dad.json configuration files. Use when Codex needs to change DAD planner-slot LevelSeekTarget values, enable SkipIfDailyRouletteRewardReceived for every character, clone a schedule's presets for another Duty Roulette target, create paired Daily and interleaved schedules, or validate and back up DAD preset/schedule configuration.
---

# Manage DAD Config

Use `scripts/dad_config.py` for deterministic JSON edits. Parse the configuration structurally; do not use broad text replacement for these operations.

## Workflow

1. Obtain the exact `dad.json` path from the user. Never assume a Windows profile or reuse a path from another user.
2. Resolve a Python 3.10+ executable. On Windows, do not use a `python.exe` resolved from `WindowsApps` when it is only the Store launcher. In Codex desktop, call `load_workspace_dependencies` and use its Python path when normal `python` is unavailable or older than 3.10.
3. Run `inspect` first and summarize the relevant counts and names.
4. For a mutation, run the command without `--write`. This is the mandatory dry-run.
5. Check the dry-run counts, retired preset names, target roulette, schedule sizes, and sample ordering against the user's request.
6. Run the identical command with `--write` only after the dry-run matches the request. Request filesystem approval when the configuration is outside the writable workspace.
7. Run `inspect` again and report the backup path plus final validation counts.

The script preserves the source encoding and newline style, detects concurrent file changes, writes atomically, creates a timestamped adjacent backup, reparses the written JSON, and refuses ambiguous names or invalid references.

## Commands

Set up shell variables for readability:

```powershell
$python = "<python-3.10+-path>"
$script = "<skill-directory>\scripts\dad_config.py"
$config = "<path-to-dad.json>"
```

### Inspect

```powershell
& $python $script $config inspect
```

Use this before and after every mutation. It reports planner and schedule counts, roulette-target distribution, LevelSeekTarget distribution, Daily checkbox state, and missing schedule references.

### Replace level-seek targets

Dry-run, then write:

```powershell
& $python $script $config set-level-seek --from-value 90 --to-value 70 --expected-changes 318
& $python $script $config set-level-seek --from-value 90 --to-value 70 --expected-changes 318 --write
```

Omit `--expected-changes` only when the user does not require an exact count. The command modifies only `PlannerGroups[*].Slots[*].LevelSeekTarget` values exactly equal to `--from-value`.

### Enable Daily for every character slot

Dry-run, then write:

```powershell
& $python $script $config enable-daily
& $python $script $config enable-daily --write
```

This sets `SkipIfDailyRouletteRewardReceived` to `true` on every planner slot, including slots where the property is absent.

### Clone presets for another roulette and create schedules

Use one existing schedule as the authoritative ordered source list and one existing preset as the roulette-target template:

```powershell
& $python $script $config clone-roulette-schedule `
  --source-schedule "Daily MSQ" `
  --roulette-template "Leveling Roulette Daily" `
  --source-prefix "MSQ" `
  --target-prefix "Leveling" `
  --target-schedule "Daily Leveling" `
  --combined-schedule "Daily MSQ+Leveling" `
  --expected-source-count 158 `
  --expected-final-count 316 `
  --retire-preset "Leveling Roulette Daily" `
  --retire-preset "<another explicitly approved unused preset>"
```

Review the dry-run, then repeat it with `--write`.

The command:

- deep-copies every preset referenced by the source schedule in source order;
- replaces only `GroupId`, `DisplayName`, `RouletteTarget`, and timestamps in each copy;
- takes the complete `RouletteTarget` object from `--roulette-template`;
- creates a target-only schedule and an alternating source/target schedule;
- creates fresh schedule and entry IDs and resets runtime history on new schedules;
- reuses explicitly retired preset IDs before generating new IDs, preserving a selected retired-template ID when possible.

`--retire-preset` is destructive to the named preset definition. Use it only for exact names the user approved after inspection. The script refuses to retire a source preset or any preset referenced by an existing schedule. Do not infer retirement merely because a preset appears unused. Omit all `--retire-preset` arguments when unrelated presets must remain; the final count will then include them.

## Guardrails

- Never include personal character names, account keys, client IDs, secrets, or the user's configuration in this skill or a shared archive.
- Never write before a successful dry-run.
- Treat `Daily MSQ` or any other source schedule as authoritative when its display names differ from underlying preset names; clones use the actual preset names.
- Preserve existing schedules, history, and active-run state. The clone command only appends the two requested schedule definitions.
- If the plugin rewrites the file after the script finishes, ask the user to stop/reload the plugin and restore or rerun from the adjacent backup.
- Stop on unexpected counts, duplicate names/IDs, missing group references, target-schedule name collisions, or a changed file hash.
